package com.programmers.java.baseball.engine.io;

public interface Input {
    String input(String s);
}
