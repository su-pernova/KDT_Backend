package com.programmers.java.baseball.engine.io;

import com.programmers.java.baseball.engine.model.Numbers;

public interface NumberGenerator {
    Numbers generate(int count);
}
