package com.programmers.java.poly;

public class KakaoLogin implements Login {
    @Override
    public void login() {
        System.out.println("카카오로 로그인 합니다.");
    }
}
