package com.programmers.java.lambda;

@FunctionalInterface
public interface MyRunnable {
    void run();
}
