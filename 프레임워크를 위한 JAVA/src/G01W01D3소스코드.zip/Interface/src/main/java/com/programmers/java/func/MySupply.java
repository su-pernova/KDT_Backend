package com.programmers.java.func;

public interface MySupply {
    String supply();
}
