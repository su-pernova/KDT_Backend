package com.programmers.java.func;

@FunctionalInterface
public interface MyRunnable {
    void run();
}
