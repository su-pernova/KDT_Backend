package com.programmers.java.poly;

public interface Login {
    void login();
}
