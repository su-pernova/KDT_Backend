package com.programmers.java.poly;

public enum LoginType {
    Kakao, Naver
}
