package com.programmers.java.def2;

public interface MyInterface {
    default void method1() {}
    default void method2() {}
    default void method3() {}
    default void method4() {}
    default void method5() {}
    default void method6() {}
    default void method7() {}
}
