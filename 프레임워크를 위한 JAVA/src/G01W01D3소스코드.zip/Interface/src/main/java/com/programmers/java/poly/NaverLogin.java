package com.programmers.java.poly;

public class NaverLogin implements Login {
    @Override
    public void login() {
        System.out.println("네이버로 로그인 합니다.");
    }
}
