package com.programmers.java;

public class ByeWorld {
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < 10; i++) {
            sb.append(i);
        }
        System.out.println(sb);
    }
}
