package com.programmers.java;


public class HelloWorld {
    public static void main(String[] args) {
        String greeting = "Hello World";
        System.out.println(greeting);
    }
}
