public class HelloWorld {
    public static void main(String[] argv) {
        String greeting = "Hello World";
        System.out.println(greeting);
    }
}